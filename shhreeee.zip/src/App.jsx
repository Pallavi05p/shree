import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./Components/Navbar";

// Pages import karo
import Home from "./Pages/Home";
import Vadya from "./Pages/Vadya";
import Events from "./Pages/Event";
import Photos from "./Pages/Photoes";
import Utsav from "./Pages/Utsav";
import Hero from "./Pages/Hero";
// import Events from "./Pages/Events";
// import Photos from "./Pages/Photos";
// import Utsav from "./Pages/Utsav";

function App() {
  return (
    <Router>
      <Hero/>
   
      <div className=""> 
           <Navbar />
        <Routes>
        
           
          <Route path="/" element={<Home />} />

          {/* Vadya Poojan page */}
          <Route path="/vadya" element={<Vadya />} />

          {/* Events page */}
          <Route path="/events" element={<Events />} />

          {/* Photos page */}
          <Route path="/photo" element={<Photos />} />

          {/* Utsav page */}
          <Route path="/utsav" element={<Utsav />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
